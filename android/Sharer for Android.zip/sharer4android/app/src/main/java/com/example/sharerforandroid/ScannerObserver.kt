package com.example.sharerforandroid

interface ScannerObserver {
    fun onScanned(scannedValue: String)
}